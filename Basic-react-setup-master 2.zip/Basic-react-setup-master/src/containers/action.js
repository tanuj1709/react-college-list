export const TEST = "TEST";

export const test = val => ({
  type: TEST,
  val
});
